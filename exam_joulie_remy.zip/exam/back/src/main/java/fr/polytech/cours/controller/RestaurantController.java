package fr.polytech.cours.controller;

import fr.polytech.cours.dto.response.RestaurantDto;
import fr.polytech.cours.dto.response.UrlDto;
import fr.polytech.cours.service.RestaurantService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
public class RestaurantController {

    private final RestaurantService RestaurantService;

    @GetMapping("/restaurants")
    public List<RestaurantDto> getRestaurants(@RequestParam(value = "id", required = false) ArrayList<Integer> idsToFetch) {
        if (idsToFetch == null || idsToFetch.isEmpty()) {
            return this.RestaurantService.getRestaurants().stream().map(RestaurantEntity -> RestaurantDto.buildFromEntity(RestaurantEntity)).toList();
        } else {
            return this.RestaurantService.getRestaurants(idsToFetch).stream().map(RestaurantEntity -> RestaurantDto.buildFromEntity(RestaurantEntity)).toList();
        }
    }

    @GetMapping("/restaurants/{id}")
    public RestaurantDto getRestaurantById(@PathVariable Integer id) {
        return RestaurantDto.buildFromEntity(this.RestaurantService.getRestaurantById(id));
    }
    @GetMapping("/restaurants/{id}/cover")
    public UrlDto getRestaurantCoverById(@PathVariable Integer id) {
        return UrlDto.builder().url(this.RestaurantService.getCoverDownloadUrl(id)).build();
    }

    @GetMapping("/restaurants/{id}/excover")
    public UrlDto putRestaurantCoverById(@PathVariable Integer id) {
        return UrlDto.builder().url(this.RestaurantService.putCoverDownloadUrl(id)).build();
    }
    @PostMapping("/restaurants")
    public RestaurantDto addRestaurant(@Valid @RequestBody RestaurantDto RestaurantDto) {
        return RestaurantDto.buildFromEntity(this.RestaurantService.addRestaurant(RestaurantDto));
    }

    @DeleteMapping("/restaurants/{id}")
    public void deleteRestaurant(@PathVariable Integer id) {
        this.RestaurantService.deleteRestaurant(id);
    }

}
