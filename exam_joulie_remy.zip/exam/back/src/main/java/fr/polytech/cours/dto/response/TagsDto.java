package fr.polytech.cours.dto.response;

import fr.polytech.cours.entity.TagsEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TagsDto {
    private Integer id;

    private String nom;




    public static TagsDto buildFromEntity(TagsEntity tagsEntity) {
        return TagsDto.builder().id(tagsEntity.getId()).nom(tagsEntity.getNom()).build();
    }
}
