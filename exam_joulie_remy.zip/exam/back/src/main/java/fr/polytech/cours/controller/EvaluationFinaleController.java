package fr.polytech.cours.controller;

import fr.polytech.cours.dto.request.AddEvaluationFinaleDto;
import fr.polytech.cours.dto.response.EvaluationFinaleDto;
import fr.polytech.cours.service.EvaluationFinaleService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequiredArgsConstructor
@Slf4j
public class EvaluationFinaleController {

    private final EvaluationFinaleService evaluationFinaleService;

    @PostMapping("/restaurants/{restaurantId}/evaluationsfinale")
    public EvaluationFinaleDto addEvaluation(@PathVariable Integer restaurantId, @Valid @RequestBody AddEvaluationFinaleDto addEvaluationFinaleDto) {
        return EvaluationFinaleDto.buildFromEntity(this.evaluationFinaleService.addEvaluationTorestaurant(restaurantId,   addEvaluationFinaleDto));
    }

}
