package fr.polytech.cours.service;

import fr.polytech.cours.dto.request.AddEvaluationFinaleDto;
import fr.polytech.cours.entity.EvaluationFinaleEntity;
import fr.polytech.cours.entity.RestaurantEntity;
import fr.polytech.cours.repository.EvaluationFinaleRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class EvaluationFinaleService {

    private final EvaluationFinaleRepository evaluationFinaleRepository;
    private final RestaurantService restaurantService;

    public EvaluationFinaleEntity addEvaluationTorestaurant(final Integer restaurantId, final AddEvaluationFinaleDto dto) {
        final RestaurantEntity restaurant = this.restaurantService.getRestaurantById(restaurantId);

        final EvaluationFinaleEntity evaluation = EvaluationFinaleEntity.builder().texte(dto.getTexte()).auteur(dto.getAuteur()).note(dto.getNote()).restaurant(restaurant).build();

        return  this.evaluationFinaleRepository.save(evaluation);

    }

}
