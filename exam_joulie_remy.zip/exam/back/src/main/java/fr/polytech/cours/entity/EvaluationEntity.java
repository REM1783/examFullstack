package fr.polytech.cours.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.time.LocalDate;

@Entity(name = "evaluation")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationEntity {

    @Id
    @GeneratedValue
    private Integer id;

    @Column(name = "texte", columnDefinition = "varchar(255)")
    private String texte;
    @Column(name="auteur", columnDefinition = "varchar(50)", nullable = false)
    private String auteur;
    @Column(name="note", columnDefinition = "INTEGER", nullable = false)
    private int note;
    @Column(name="datedePublication",columnDefinition="DATE",nullable = false)
    private LocalDate datedePublication;
    @Column(name="image",columnDefinition = "TEXT",nullable = true)
    private String image;
    @ManyToOne()
    @JoinColumn(name = "restaurant")
    private RestaurantEntity restaurant;

}
