package fr.polytech.cours.dto.response;

import com.fasterxml.jackson.annotation.JsonProperty;
import fr.polytech.cours.entity.RestaurantEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RestaurantDto {

    @JsonProperty("id")
    private Integer id;

    @JsonProperty("nom")
    private String nom;
    @JsonProperty("adresse")
    private String adresse;
    @JsonProperty("jacquette")
    private String jacquette;
    @JsonProperty("evaluation")
    private List<EvaluationDto> evaluation;
    @JsonProperty("evaluationFinale")
    private EvaluationFinaleDto evaluationFinale;
    public static RestaurantDto buildFromEntity(RestaurantEntity restaurantEntity) {
        return RestaurantDto.builder()
                .id(restaurantEntity.getId())
                .nom(restaurantEntity.getNom())
                .adresse(restaurantEntity.getAdresse())
                .jacquette(restaurantEntity.getJacquette())
                .evaluation(restaurantEntity.getEvaluations().stream().map(evaluationEntity ->  EvaluationDto.buildFromEntity(evaluationEntity)).toList())
               // .evaluationFinale(restaurantEntity.getEvaluationsFinale().stream().map(evaluationFinaleEntity -> EvaluationFinaleDto.buildFromEntity(E)))
                .build();
    }

}
