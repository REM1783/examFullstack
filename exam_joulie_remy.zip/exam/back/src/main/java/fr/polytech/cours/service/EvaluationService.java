package fr.polytech.cours.service;

import fr.polytech.cours.dto.request.AddEvaluationDto;
import fr.polytech.cours.entity.EvaluationEntity;
import fr.polytech.cours.entity.RestaurantEntity;
import fr.polytech.cours.exception.ResourceNotFoundException;
import fr.polytech.cours.repository.EvaluationRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;

@Service
@RequiredArgsConstructor
@Slf4j
public class EvaluationService {

    private final EvaluationRepository evaluationRepository;
    private final RestaurantService restaurantService;
    private S3Service s3Service;

    public EvaluationEntity addEvaluationTorestaurant(final Integer restaurantId, final AddEvaluationDto dto) {
        final RestaurantEntity restaurant = this.restaurantService.getRestaurantById(restaurantId);

        final EvaluationEntity evaluation = EvaluationEntity.builder().texte(dto.getTexte()).auteur(dto.getAuteur()).note(dto.getNote()).restaurant(restaurant).datedePublication(LocalDate.now()).image("S3-remy-evaluation-photo"+dto.getTexte()).build();

        return  this.evaluationRepository.save(evaluation);
    }
    public String getCoverDownloadUrl(final Integer identifiant) {

        return this.s3Service.getDownloadUrl(getEvaluationById(identifiant).getImage(),"evaluation");
    }

    private EvaluationEntity getEvaluationById(Integer identifiant) {
        return this.evaluationRepository.findById(identifiant).orElseThrow(() -> new ResourceNotFoundException("commentaire with id " + identifiant + " + not found"));

    }

    public String putCoverDownloadUrl(final Integer identifiant) {

        return this.s3Service.putDownloadUrl(getEvaluationById(identifiant).getImage(),"evaluation");
    }

}
