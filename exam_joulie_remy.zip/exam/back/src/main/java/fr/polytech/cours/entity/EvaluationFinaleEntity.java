package fr.polytech.cours.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;

@Entity(name = "evaluationfinale")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationFinaleEntity {

    @Id
    @GeneratedValue
    private Integer id;

    @Column(name = "texte", columnDefinition = "varchar(255)")
    private String texte;
    @Column(name="auteur", columnDefinition = "varchar(50)", nullable = false)
    private String auteur;
    @Column(name="note", columnDefinition = "INTEGER", nullable = false)
    private int note;
    @OneToOne()
    @JoinColumn(name = "restaurant")
    private RestaurantEntity restaurant;

}
