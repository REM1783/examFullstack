package fr.polytech.cours.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Date;
import java.util.List;

@Entity(name = "restaurant")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RestaurantEntity {

    @Id
    @GeneratedValue()
    private Integer id;

    @Column(name = "nom", columnDefinition = "varchar(255)", nullable = false)
    private String nom;
    @Column(name = "adressse", columnDefinition = "TEXT", nullable = false)
    private String adresse;
    @Column(name = "jacquette", columnDefinition = "TEXT", nullable = false)
    private String jacquette;

    @OneToMany(mappedBy = "restaurant")
    private List<EvaluationEntity> evaluations;
    @OneToOne(mappedBy = "restaurant")
    private EvaluationFinaleEntity evaluationsFinale;
    @OneToMany(mappedBy = "restaurant")
    private List<TagsEntity> tags;


}
