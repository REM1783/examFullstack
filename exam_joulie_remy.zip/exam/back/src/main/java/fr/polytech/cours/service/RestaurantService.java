package fr.polytech.cours.service;

import fr.polytech.cours.dto.response.RestaurantDto;
import fr.polytech.cours.entity.RestaurantEntity;
import fr.polytech.cours.exception.InvalidValueException;
import fr.polytech.cours.exception.ResourceNotFoundException;
import fr.polytech.cours.repository.RestaurantRepository;
import io.minio.MinioClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
@RequiredArgsConstructor
public class RestaurantService {

    private final RestaurantRepository restaurantRepository;
    private final S3Service s3Service;
    //private final EvaluationService evaluationService;
    private MinioClient client;




    public List<RestaurantEntity> getRestaurants() {
        return this.restaurantRepository.findAll();
    }

    public List<RestaurantEntity> getRestaurants(final List<Integer> idsToFetch) {
        return this.restaurantRepository.findAllById(idsToFetch);
    }

    public RestaurantEntity getRestaurantById(final Integer id) {
        return this.restaurantRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("restaurant with id " + id + " + not found"));
    }

    public RestaurantEntity addRestaurant(final RestaurantDto restaurantDto) {
        String nomJacquette="remy-S3-service-"+restaurantDto.getNom();
        if((restaurantDto.getJacquette() !=null)){
            nomJacquette=restaurantDto.getJacquette();
        }
        final RestaurantEntity restaurantToInsert = RestaurantEntity.builder().adresse(restaurantDto.getAdresse()).jacquette(nomJacquette).nom(restaurantDto.getNom()).evaluations(new ArrayList<>()).build();
        RestaurantEntity resultat_insert = this.restaurantRepository.save(restaurantToInsert);

       /*    if(restaurantDto.getEvaluations()!=null){
       for( evaluation : restaurantDto.getEvaluations()) {
                evaluationService.addEvaluationTorestaurant(resultat_insert.getId() );
            }
        }*/
        return resultat_insert;
    }

    public void deleteRestaurant(final Integer id) {
        this.restaurantRepository.deleteById(id);
    }

    public RestaurantEntity updateRestaurant(int id, String nouveauNom) {
        if (nouveauNom == null) {
            throw new InvalidValueException("le nouveau nom ne doit pas être null");
        }
        final RestaurantEntity restaurantToUpdate = this.restaurantRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("le restaurant d'id " + id + " n'existe pas"));
        restaurantToUpdate.setNom(nouveauNom);
        restaurantRepository.save(restaurantToUpdate);
        return restaurantToUpdate;
    }

    public String getCoverDownloadUrl(final Integer identifiant) {

        return this.s3Service.getDownloadUrl(getRestaurantById(identifiant).getJacquette(),"restaurant");
    }

    public String putCoverDownloadUrl(final Integer identifiant) {

        return this.s3Service.putDownloadUrl(getRestaurantById(identifiant).getJacquette(),"restaurant");
    }

}
