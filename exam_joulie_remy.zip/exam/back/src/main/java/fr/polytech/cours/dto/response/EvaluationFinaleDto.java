package fr.polytech.cours.dto.response;

import fr.polytech.cours.entity.EvaluationFinaleEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationFinaleDto {

    private Integer id;

    private String texte;
    private String auteur;
    private int note;


    public static EvaluationFinaleDto buildFromEntity(EvaluationFinaleEntity evaluationFinaleEntity) {
        return EvaluationFinaleDto.builder().id(evaluationFinaleEntity.getId()).texte(evaluationFinaleEntity.getTexte()).auteur(evaluationFinaleEntity.getAuteur()).note(evaluationFinaleEntity.getNote()).build();
    }

}
