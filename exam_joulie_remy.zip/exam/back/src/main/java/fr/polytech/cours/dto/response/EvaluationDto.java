package fr.polytech.cours.dto.response;

import fr.polytech.cours.entity.EvaluationEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EvaluationDto {

    private Integer id;

    private String texte;
    private String auteur;
    private int note;
    private LocalDate date;


    public static EvaluationDto buildFromEntity(EvaluationEntity evaluationEntity) {
        return EvaluationDto.builder().date(evaluationEntity.getDatedePublication()).id(evaluationEntity.getId()).texte(evaluationEntity.getTexte()).auteur(evaluationEntity.getAuteur()).note(evaluationEntity.getNote()).build();
    }

}
