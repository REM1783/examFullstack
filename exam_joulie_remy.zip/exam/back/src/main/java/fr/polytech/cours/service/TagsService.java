package fr.polytech.cours.service;

import fr.polytech.cours.dto.response.TagsDto;
import fr.polytech.cours.entity.RestaurantEntity;
import fr.polytech.cours.entity.TagsEntity;
import fr.polytech.cours.exception.ResourceNotFoundException;
import fr.polytech.cours.repository.TagsRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class TagsService {
    private final TagsRepository tagsRepository;
    private TagsService tagsService;

    public TagsEntity addTags(TagsDto tagsDto) {

        final TagsEntity tagsToInsert = TagsEntity.builder().nom(tagsDto.getNom()).build();

        return  this.tagsRepository.save(tagsToInsert);
    }
        public TagsEntity getTagsById(final Integer id) {
            return this.tagsRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("restaurant with id " + id + " + not found"));
        }


    public List<TagsEntity> getTags(ArrayList<Integer> idsToFetch) {
        return this.tagsRepository.findAll();
    }
    public List<TagsEntity> getRestaurants(final List<Integer> idsToFetch) {
        return this.tagsRepository.findAllById(idsToFetch);
    }
}
