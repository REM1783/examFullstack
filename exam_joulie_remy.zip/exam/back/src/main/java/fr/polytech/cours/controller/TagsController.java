package fr.polytech.cours.controller;

import fr.polytech.cours.dto.response.TagsDto;
import fr.polytech.cours.dto.response.UrlDto;
import fr.polytech.cours.service.TagsService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
public class TagsController {
    private final TagsService tagsService;
    @PostMapping("/tags")
    public TagsDto addTags(@Valid @RequestBody TagsDto TagsDto) {
        return TagsDto.buildFromEntity(this.tagsService.addTags(TagsDto));
    }
    @GetMapping("/tags")
    public List<TagsDto> getTags(@RequestParam(value = "id", required = false) ArrayList<Integer> idsToFetch) {
        if (idsToFetch == null || idsToFetch.isEmpty()) {
            return this.tagsService.getTags(idsToFetch).stream().map(TagsEntity -> TagsDto.buildFromEntity(TagsEntity)).toList();
        } else {
            return this.tagsService.getTags(idsToFetch).stream().map(TagsEntity -> TagsDto.buildFromEntity(TagsEntity)).toList();
        }
    }



}
