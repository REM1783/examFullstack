package fr.polytech.cours.service;

import fr.polytech.cours.entity.RestaurantEntity;
import fr.polytech.cours.exception.InvalidValueException;
import fr.polytech.cours.exception.ResourceNotFoundException;
import fr.polytech.cours.repository.RestaurantRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
public class RestaurantServiceTest {

    @Mock
    private RestaurantRepository restaurantRepository;

    @InjectMocks
    private RestaurantService restaurantService;

    @Test
    public void update_restaurant_with_null_name() {
        assertThrows(InvalidValueException.class, () -> this.restaurantService.updateRestaurant(0, null));
    }

    @Test
    public void update_restaurant_with_non_existing_restaurant() {
        assertThrows(ResourceNotFoundException.class, () -> this.restaurantService.updateRestaurant(0, "toto"));
    }

    @Test
    public void update_restaurant_ok() {
        when(this.restaurantRepository.findById(anyInt())).thenReturn(Optional.of(RestaurantEntity.builder().build()));
        final RestaurantEntity result = this.restaurantService.updateRestaurant(123, "toto");

        assertEquals("toto", result.getTitre());
    }

}
