import {Component, OnInit} from '@angular/core';
import { CommonModule } from '@angular/common';
import {RestaurantDisplayComponent} from "../restaurantDetail-display/restaurant-display.component";
import {DetailRestaurantModComponent} from "../detailRestaurant-mod/detailRestaurant-mod.component";
import {ActivatedRoute} from "@angular/router";
import {RestaurantService} from "../../../services/restaurant.service";
import {RestaurantDto} from "../../../models/dto/restaurant.dto";

@Component({
  selector: 'app-restaurant',
  standalone: true,
  imports: [CommonModule, RestaurantDisplayComponent, DetailRestaurantModComponent],
  templateUrl: './detailRestaurant.component.html',
  styleUrl: './detailRestaurant.component.css'
})
export class DetailRestaurantComponent implements OnInit {
    public restaurants: RestaurantDto[] = [];
    constructor(private route: ActivatedRoute,private readonly restaurantService: RestaurantService) {}
    ngOnInit(): void {

            this.refreshrestaurants();


    }
    public getCover(restaurant: RestaurantDto): void {
        this.restaurantService.getrestaurantCover(restaurant.id).subscribe(urlDto => {
            restaurant.coverUrl = urlDto.url;
        });
    }
    //j'ai un pb d'identifiants avec ma méthode
    public refreshrestaurants() {
        if (this.route.snapshot.paramMap.get('id') != null) {
          console.log(this.route.snapshot.paramMap.get('id'));
          this.restaurantService.loadrestaurantsbyID( this.route.snapshot.paramMap.get('id')).subscribe(value => {
                this.restaurants = value;
                this.restaurants.forEach(restaurant => this.getCover(restaurant));
            })
        } else {
            console.log("error router");
        }
    }
}
