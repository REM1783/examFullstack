import {Component, Input} from '@angular/core';
import {CommonModule, NgOptimizedImage} from '@angular/common';
import {TableBlueOrRedDirective} from "../../../directives/table-blue-or-red.directive";
import {RestaurantDto} from "../../../models/dto/restaurant.dto";

@Component({
  selector: 'app-restaurantDetail-display',
  standalone: true,
    imports: [CommonModule, TableBlueOrRedDirective, NgOptimizedImage],
  templateUrl: './restaurant-display.component.html',
  styleUrl: './restaurant-display.component.css'
})
export class RestaurantDisplayComponent {

    @Input() restaurants: RestaurantDto[] = [];



}
