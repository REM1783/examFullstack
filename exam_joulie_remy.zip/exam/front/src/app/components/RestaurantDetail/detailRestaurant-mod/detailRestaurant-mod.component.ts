import {Component, EventEmitter, Output} from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-restaurantDetail-mod',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './detailRestaurant-mod.component.html',
  styleUrl: './detailRestaurant-mod.component.css'
})
export class DetailRestaurantModComponent {

  @Output() addValue: EventEmitter<number> = new EventEmitter<number>()
  @Output() reset: EventEmitter<void> = new EventEmitter<void>()

  public addValeur(value: number): void {
    this.addValue.emit(value);
  }

  public resetValeur(): void {
    this.reset.emit();
  }

}
