import {Component, OnInit} from '@angular/core';
import {CommonModule, NgOptimizedImage} from '@angular/common';
import {RestaurantService} from "../../../services/restaurant.service";
import {RestaurantDto} from "../../../models/dto/restaurant.dto";
import {RestaurantDisplayComponent} from "../restaurant-display/restaurant-display.component";
import {AddrestaurantFormComponent, AddrestaurantFormData} from "../add-restaurant-form/add-restaurant-form";
import {AddPictureRestaurantComponent, AddPictureFormData} from "../add-picture-restaurant-form/add-picture-restaurant-component";

@Component({
  selector: 'app-restaurant',
  standalone: true,
  imports: [CommonModule, NgOptimizedImage, RestaurantDisplayComponent, AddrestaurantFormComponent, AddPictureRestaurantComponent],
  templateUrl: './restaurant.component.html',
  styleUrl: './restaurant.component.css'
})
export class RestaurantComponent implements OnInit {

  public restaurants: RestaurantDto[] = [];

  constructor(private readonly restaurantService: RestaurantService) {
  }

  ngOnInit(): void {
    this.refreshrestaurants();
  }

  public refreshrestaurants() {
    this.restaurantService.loadrestaurants().subscribe(value => {
      this.restaurants = value;
      this.restaurants.forEach(restaurant => this.getCover(restaurant));
    })
  }

  public getCover(restaurant: RestaurantDto): void {
    this.restaurantService.getrestaurantCover(restaurant.id).subscribe(urlDto => {
      restaurant.coverUrl = urlDto.url;
    });
  }

  public onrestaurantSubmitted(newrestaurantData: AddrestaurantFormData): void {
    this.restaurantService.addrestaurant(newrestaurantData).subscribe(value => {
      this.restaurants.push(value);
      this.getCover(value);
    })
  }

  onrestaurantPictueSubmitted(PictureMovie: AddPictureFormData) {
    if(PictureMovie.image) {
      const file = PictureMovie.image
      this.restaurantService.geturlExCover(PictureMovie.id).subscribe(value => {
        this.pushPicture(value.url, file);
      })
    }
  }

  private pushPicture(url: string, image: File) {
    console.log(url);
    this.restaurantService.pushImage(url,image).subscribe()
  }
}
