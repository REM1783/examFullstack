import {Component, EventEmitter, Output} from '@angular/core';
import {CommonModule} from '@angular/common';
import {FormsModule, NgForm} from "@angular/forms";
import {ErrorDirective} from "../../../directives/error.directive";

@Component({
  selector: 'app-add-picture-restaurant',
  standalone: true,
  imports: [CommonModule, FormsModule, ErrorDirective],
  templateUrl: './add-picture-restaurant-component.html',
  styleUrl: './add-picture-restaurant-component.css'
})
export class AddPictureRestaurantComponent {

  @Output("restaurantPictureSubmitted") restaurantPictueSubmittedEmiter = new EventEmitter<AddPictureFormData>();

  public formData: AddPictureFormData = {
    id: 0,
    image: undefined

  }

  public submit(form: NgForm): void {
    if (form.valid) {
      this.restaurantPictueSubmittedEmiter.emit(this.formData);
    }
  }

}

export interface AddPictureFormData {
  image?: File;
  id: number

}
