import {Injectable} from '@angular/core';
import {RestaurantDto} from "../models/dto/restaurant.dto";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {UrlDto} from "../models/dto/url.dto";
import {AddrestaurantFormData} from "../components/restaurant/add-restaurant-form/add-restaurant-form";

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(private httpClient: HttpClient) {
    this.loadrestaurants();
  }

  public loadrestaurants(): Observable<RestaurantDto[]> {
    return this.httpClient.get<RestaurantDto[]>(`http://localhost:8080/restaurants`);
  }
  public loadrestaurantsbyID(id: string | null): Observable<RestaurantDto[]> {
     return this.httpClient.get<RestaurantDto[]>(`http://localhost:8080/restaurants/${id}`);
    }

  public getrestaurantCover(id: number): Observable<UrlDto> {
    return this.httpClient.get<UrlDto>(`http://localhost:8080/restaurants/${id}/cover`);
  }
  public geturlExCover(id: number): Observable<UrlDto> {
    return this.httpClient.get<UrlDto>(`http://localhost:8080/restaurants/${id}/excover`);
  }

  public addrestaurant(newrestaurantData: AddrestaurantFormData): Observable<RestaurantDto> {
    return this.httpClient.post<RestaurantDto>(`http://localhost:8080/restaurants`, newrestaurantData);
  }

  pushImage(url: string, image: File) {
    console.log(typeof image)
    return this.httpClient.put(url,image.stream);

  }
}
