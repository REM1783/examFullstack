import {Routes} from '@angular/router';
import {DetailRestaurantComponent} from "./components/RestaurantDetail/DetailRestaurant/detailRestaurant.component";
import {RestaurantComponent} from "./components/restaurant/restaurant-componement/restaurant.component";

export const routes: Routes = [

  {
    path: 'restaurant/:id', component: DetailRestaurantComponent
  },
  {
    path: '', component: RestaurantComponent
  }
];
