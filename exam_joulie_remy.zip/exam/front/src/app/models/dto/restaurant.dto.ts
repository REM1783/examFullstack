export interface RestaurantDto {
  id: number;
  nom: string;
  adresse: string;
  coverUrl?: string;
}


