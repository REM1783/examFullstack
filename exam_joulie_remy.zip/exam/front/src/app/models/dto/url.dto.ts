export interface UrlDto {
  url: string
}
